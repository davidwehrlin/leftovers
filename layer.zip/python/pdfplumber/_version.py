version_info = (0, 5, 22)
__version__ = '.'.join(map(str, version_info))
